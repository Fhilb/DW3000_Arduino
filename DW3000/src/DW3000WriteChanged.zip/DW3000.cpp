/*
 * Copyright (c) 2023 by Philipp Hafkemeyer
 * Qorvo DW3000 library for Arduino
 *
 * This project is licensed under the GNU GPL v3.0 License.
 * you may not use this file except in compliance with the License.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*/

#include "Arduino.h"
#include "SPI.h"
#include <stdlib.h>
#include "DW3000.h"

DW3000Class DW3000;

#define CHIP_SELECT_PIN 4
#define RST_PIN 27

#define DEBUG_OUTPUT 0 //Turn to 1 to get all reads, writes, etc. as info in the console

int led_status = 0;

int DW3000Class::config[] = { //CHAN; PREAMBLE LENGTH; PREAMBLE CODE; PAC; DATARATE; PHR_MODE; PHR_RATE;
    CHANNEL_5,
    PREAMBLE_128,
    9, //same for tx and rx
    PAC8,
    DATARATE_6_8MB,
    PHR_MODE_STANDARD,
    PHR_RATE_850KB
};

bool DW3000Class::cmd_error = false;

void DW3000Class::begin() {
    delay(5);
    pinMode(CHIP_SELECT_PIN, OUTPUT);
    SPI.begin();

    delay(5);
    //attachInterrupt(digitalPinToInterrupt(2), DW3000Class::interruptDetect, RISING

    spiSelect(CHIP_SELECT_PIN);

    Serial.println("[INFO] SPI ready");
    
}

void DW3000Class::hardReset() {
    pinMode(RST_PIN, OUTPUT);
    digitalWrite(RST_PIN, LOW); // set reset pin active low to hard-reset DW3000 chip
    delay(10);
    pinMode(RST_PIN, INPUT); // get pin back in floating state
}


void DW3000Class::spiSelect(uint8_t cs) {
    pinMode(cs, OUTPUT);
    digitalWrite(cs, HIGH);

    delay(5);
}

void DW3000Class::printFullConfig() {
    int tmp_size = 20;
    int tmp[tmp_size];
    Serial.println("\n\n#####     READING FULL CONFIG     #####\n");
    tmp[0] = read(0x00, 0x10);
    tmp[1] = read(0x00, 0x24);
    tmp[2] = read(0x00, 0x28);
    tmp[3] = read(0x00, 0x44);
    tmp[4] = read(0x01, 0x14);
    tmp[5] = read(0x02, 0x00);
    tmp[6] = read(0x03, 0x18);
    tmp[7] = read(0x04, 0x0C);
    tmp[8] = read(0x04, 0x20);
    tmp[9] = read(0x06, 0x00);
    tmp[10] = read(0x06, 0x0C);
    tmp[11] = read(0x07, 0x10);
    tmp[12] = read(0x07, 0x18);
    tmp[13] = read(0x07, 0x1C);
    tmp[14] = read(0x07, 0x50);
    tmp[15] = read(0x09, 0x00);
    tmp[16] = read(0x09, 0x08);
    tmp[17] = read(0x11, 0x04);
    tmp[18] = read(0x11, 0x08);
    tmp[19] = read(0x0E, 0x12);
    Serial.println("\n\n#####     PRINTING FULL CONFIG     #####\n");

    for (int i = 0; i < tmp_size; i++) {
        Serial.println(tmp[i], BIN);
    }
}

void DW3000Class::writeSysConfig() {
    int usr_cfg = (STDRD_SYS_CONFIG & 0xFFF) | (config[5] << 3) | (config[6] << 4);
    write(GEN_CFG_AES_LOW_REG, 0x10, usr_cfg & 0xFFF); //write user config
    if (config[2] > 24) {
        Serial.println("[ERROR] SCP ERROR! TX & RX Preamble Code higher than 24!");
    }
    int otp_write = 0x1400;

    if (config[1] >= 256) {
        otp_write = 0x0400;
    }

    write(OTP_IF_REG, 0x08, otp_write); //set OTP config
    write(DRX_REG, 0x00, 0x00, 1); //reset DTUNE0_CONFIG
    write(DRX_REG, 0x00, config[3]);
    //64 = STS length
    write(STS_CFG_REG, 0x0, 64 / 8 - 1);
    
    write(GEN_CFG_AES_LOW_REG, 0x29, 0x00, 1);

    //TODO if not working: change value back (p.147)
    write(DRX_REG, 0x0C, 0xAF5F584C);
    
    int chan_ctrl_val = read(GEN_CFG_AES_HIGH_REG, 0x14);  //Fetch and adjust CHAN_CTRL data
    chan_ctrl_val &= (~0x1FFF);

    chan_ctrl_val |= config[0]; //Write RF_CHAN
    
    chan_ctrl_val |= 0x1F00 & (config[2] << 8);
    chan_ctrl_val |= 0xF8 & (config[2] << 3);
    chan_ctrl_val |= 0x06 & (0x01 << 1);


    write(GEN_CFG_AES_HIGH_REG, 0x14, chan_ctrl_val);  //Write new CHAN_CTRL data with updated values

    int tx_fctrl_val = read(GEN_CFG_AES_LOW_REG, 0x24); 

    tx_fctrl_val |= (config[1] << 12); //Add preamble length
    tx_fctrl_val |= (config[4] << 10); //Add data rate

    write(GEN_CFG_AES_LOW_REG, 0x24, tx_fctrl_val);

    write(DRX_REG, 0x02, 0x81);

    int rf_tx_ctrl_2_data = 0x1C071134;
    int pll_conf = 0x0F3C;

    if (config[0]) {
        rf_tx_ctrl_2_data = ~(~rf_tx_ctrl_2_data & 0xFF00);
        rf_tx_ctrl_2_data = ~(~rf_tx_ctrl_2_data & 0xFE0000);
        pll_conf = ~(~pll_conf & 0xE000);
    }

    write(RF_CONF_REG, 0x1C, rf_tx_ctrl_2_data);
    write(FS_CTRL_REG, 0x00, pll_conf);

    write(RF_CONF_REG, 0x51, 0x14);

    write(RF_CONF_REG, 0x1A, 0x0E);

    write(FS_CTRL_REG, 0x08, 0x81);

    write(GEN_CFG_AES_LOW_REG, 0x44, 0x02);
    
    write(PMSC_REG, 0x04, 0x300200); //Set clock to auto mode

    write(PMSC_REG, 0x08, 0x0138);

    int success = 0;
    for (int i = 0; i < 100; i++) {
        if (read(GEN_CFG_AES_LOW_REG, 0x0) & 0x2) {
            success = 1;
            break;
        }
    }

    if (!success) {
        Serial.println("[ERROR] Couldn't lock PLL Clock!");
    }
    else {
        Serial.println("[INFO] PLL is now locked.");
    }

    int otp_val = read(OTP_IF_REG, 0x08);
    otp_val |= 0x40;
    if (config[0]) otp_val |= 0x2000;

    write(OTP_IF_REG, 0x08, otp_val);

    write(RX_TUNE_REG, 0x19, 0xF0);

    int ldo_ctrl_val = read(RF_CONF_REG, 0x48); //Save original LDO_CTRL data for later

    int tmp_ldo = (0x105 |
        0x100 |
        0x4 |
        0x1);
    
    write(RF_CONF_REG, 0x48, tmp_ldo);

    write(EXT_SYNC_REG, 0x0C, 0x020000); //Calibrate RX

    //int l = read(0x04, 0x0C);

    //delay(20);

    write(EXT_SYNC_REG, 0x0C, 0x11); //Enter CAL_MODE and enable RX_Calibration
    
    for (int i = 0; i < 100; i++) {
        /*Serial.print("cal res I: ");
        Serial.println(read(0x4, 0x14), HEX);
        Serial.print("cal res Q: ");
        Serial.println(read(0x4, 0x1C), HEX);
        delay(50);*/
    }
    int succ = 0;
    for (int i = 0; i < 100; i++) {
        if (read(EXT_SYNC_REG, 0x20)) {
            succ = 1;
            break;
        }
        delay(10);
    }

    if (succ) {
        Serial.println("[INFO] PGF calibration complete.");
    }
    else {
        Serial.println("[ERROR] PGF calibration failed!");
    }

    write(EXT_SYNC_REG, 0x20, 0x01);

    int rx_cal_res = read(EXT_SYNC_REG, 0x14);
    if (rx_cal_res == 0x1fffffff) {
        Serial.println("[ERROR] PGF_CAL failed in stage I!");
    }
    rx_cal_res = read(EXT_SYNC_REG, 0x1C);
    if (rx_cal_res == 0x1fffffff) {
        Serial.println("[ERROR] PGF_CAL failed in stage Q!");
    }

    write(RF_CONF_REG, 0x48, ldo_ctrl_val); //Restore original LDO_CTRL data
}

void DW3000Class::configureAsTX() {
    write(RF_CONF_REG, 0x1C, 0x34); //write pg_delay
    write(GEN_CFG_AES_HIGH_REG, 0x0C, 0xFDFDFDFD);
}


void DW3000Class::setTXFrame(unsigned long long frame_data) {  // deprecated! use write(TX_BUFFER_REG, [...]);
    if (frame_data > ((pow(2, 8 * 8) - FCS_LEN))) {
        Serial.println("[ERROR] Frame is too long (> 1023 Bytes - FCS_LEN)!");
        return;
    }

    int frame_len_bits = countBits(frame_data);
    int frame_len = (frame_len_bits - frame_data % 8) / 8; //calc the used bytes for transaction
    if (frame_data % 8 > 0) frame_len++;

    write(TX_BUFFER_REG, 0x00, frame_data, frame_len);
}

int DW3000Class::getAnchorID() {
	return anchor_id;
}

uint32_t DW3000Class::sendBytes(int b[], int lenB, int recLen) { //WORKING
    digitalWrite(CHIP_SELECT_PIN, LOW);
    for (int i = 0; i < lenB; i++) {
        SPI.transfer(b[i]);
    }
    int rec;
    uint32_t val, tmp;
    if (recLen > 0) {
        for (int i = 0; i < recLen; i++) {
            tmp = SPI.transfer(0x00);
            if (i == 0) {
                val = tmp; //Read first 4 octets
            }
            else {
                val |= (uint32_t)tmp << 8 * i;
            }
        }
    }
    else {
        val = 0;
    }
    digitalWrite(CHIP_SELECT_PIN, HIGH);
    return val;
}

bool DW3000Class::checkForIDLE() {
   return (read(0x0F, 0x30) >> 16 & PMSC_STATE_IDLE) == PMSC_STATE_IDLE || (read(0x00, 0x44) >> 16 & (SPIRDY_MASK | RCINIT_MASK)) == (SPIRDY_MASK | RCINIT_MASK) ? 1 : 0;
}

/*uint32_t DW3000Class::readOrWriteFullAddress(int* base, int base_len, int* sub, int sub_len, int* data, int data_len, int readWriteBit) {
    return DW3000Class::readOrWriteFullAddress(base, base_len, sub, sub_len, data, data_len, readWriteBit, false);
}*/

void DW3000Class::softReset() {
    clearAONConfig();

    write(PMSC_REG, 0x04, 0x1); //force clock to FAST_RC/4 clock
    
    write(PMSC_REG, 0x00, 0x00, 2); //init reset

    delay(100);

    write(PMSC_REG, 0x00, 0xFFFF); //return back

    write(PMSC_REG, 0x04, 0x00, 1); //set clock back to Auto mode
}

void DW3000Class::clearAONConfig() {
    write(AON_REG, NO_OFFSET, 0x00, 2);
    write(AON_REG, 0x14, 0x00, 1);

    write(AON_REG, 0x04, 0x00, 1); //clear control of aon reg

    write(AON_REG, 0x04, 0x02);

    delay(1);
}

uint32_t DW3000Class::readOrWriteFullAddress(int base, int sub, int data, int data_len, int readWriteBit) {
    int header = 0x00;

    if (readWriteBit) header = header | 0x80;

    header = header | ((base & 0x1F) << 1);

    if (sub > 0) {
        header = header | 0x40;
        header = header << 8;
        header = header | ((sub & 0x7F) << 2);
    }

    int header_size = header > 0xFF ? 2 : 1;

    uint32_t res = 0;
    
    if (!readWriteBit) {
        int headerArr[header_size];

        if (header_size == 1) {
            headerArr[0] = header;
        }
        else {
            headerArr[0] = (header & 0xFF00) >> 8;
            headerArr[1] = header & 0xFF;
        }

        res = (uint32_t)sendBytes(headerArr, header_size, 4);
        return res;
    }
    else {
        int payload_bytes = 0;
        if(data_len == 0){
            if(data > 0){
                int payload_bits = countBits(data);
                payload_bytes = (payload_bits - data % 8) / 8; //calc the used bytes for transaction
                if (data % 8 > 0) payload_bytes++;
            }
            else {
                payload_bytes = 1;
            }
        }
        else {
            payload_bytes = data_len;
        }

        int payload[header_size + payload_bytes];

        if (header_size == 1) {
            payload[0] = header;
        }
        else {
            payload[0] = (header & 0xFF00) >> 8;
            payload[1] = header & 0xFF;
        }

        for (int i = 0; i < payload_bytes; i++) {
            payload[header_size + i] = (data >> i * 8) & 0xFF;
        }

        /*Serial.println("Sending following data to chip:");
        for (int i = 0; i < 2 + payload_bytes; i++) {
            Serial.println(payload[i], BIN);
        }*/
        
        res = (uint32_t)sendBytes(payload, 2 + payload_bytes, 0);
        return res;
    }



    //int fill_base_len = 5;
    //int num_zeros = fill_base_len - base_len;
    //if (num_zeros < 0) {
    //    num_zeros = 0;
    //}
    //int fill_base[fill_base_len]; //fill leading zeros

    //for (int i = 0; i < fill_base_len; i++) {
    //    fill_base[num_zeros + i] = base[i];
    //}


    //int fill_sub_len = 7;
    //int fill_sub[fill_sub_len]; //fill leading zeros  
    //num_zeros = fill_sub_len - sub_len;
    //if (num_zeros < 0) {
    //    num_zeros = 0;
    //}
    //for (int i = 0; i < fill_sub_len; i++) {
    //    fill_sub[num_zeros + i] = sub[i];
    //}

    //int first_byte[8] = { readWriteBit, 1 };
    //for (int i = 0; i < fill_base_len; i++) {
    //    first_byte[i + 2] = fill_base[i];
    //}
    //first_byte[7] = fill_sub[0];

    //int second_byte[8];
    //second_byte[8 - 1] = 0; //Last two bits are set to 0 (mode selector bits)
    //second_byte[8 - 2] = 0;

    //for (int i = 0; i < fill_sub_len - 1; i++) {
    //    second_byte[i] = fill_sub[i + 1];
    //}

    //int byteOne = 0;
    //int byteTwo = 0;

    //for (int i = 7; i >= 0; i--) {
    //    byteOne = byteOne + first_byte[i] * round(pow(2, 7 - i));
    //    byteTwo = byteTwo + second_byte[i] * round(pow(2, 7 - i));
    //}

    //uint32_t val;

    //int bytes[data_len + 2] = { byteOne, byteTwo };

    //for (int i = 0; i < data_len; i++) {
    //    bytes[i + 2] = data[i];
    //}

    //uint32_t res;

    //if (readWriteBit == 0) {
    //    if (DEBUG_OUTPUT) {
    //        Serial.print("Reading from ");
    //        for (int i = 0; i < fill_base_len; i++) {
    //            Serial.print(fill_base[i]);
    //        }
    //        Serial.print(":");
    //        for (int i = 0; i < fill_sub_len; i++) {
    //            Serial.print(fill_sub[i]);
    //        }
    //        Serial.println("");
    //    }
    //    
    //    res = (uint32_t)sendBytes(bytes, 2 + data_len, 4);

    //    if (DEBUG_OUTPUT) {
    //        Serial.print("Received result (HEX): ");
    //        Serial.print(res, HEX);
    //        Serial.print(" (BIN): ");
    //        Serial.println(res, BIN);
    //    }
    //    return res;
    //}
    //else {
    //    if (DEBUG_OUTPUT) {
    //        Serial.print("Writing to ");
    //        for (int i = 0; i < fill_base_len; i++) {
    //            Serial.print(fill_base[i]);
    //        }
    //        Serial.print(":");
    //        for (int i = 0; i < fill_sub_len; i++) {
    //            Serial.print(fill_sub[i]);
    //        }
    //        Serial.println("");
    //    }
    //    res = (uint32_t)sendBytes(bytes, 2 + data_len, 0);
    //    return res;
    //}
}

/*
* var size can be 1, 2 or 4 
* 
* see DW3000 Family User Manual pdf chapter 2.3.1.2 Figure 2 (M1 and M0 bits) for more
*/
void DW3000Class::writeANDorOR(int base, int sub, int and_data, int or_data, int size) {
    int header = 0x80;

    header = header | ((base & 0x1F) << 1);

        header = header | 0x40;
        header = header << 8;
        header = header | ((sub & 0x7F) << 2);
        int mode_bits = 0;

        if ((size & ~0x03) > 0) { // If error thrown: See function description
            Serial.print("[ERROR] writeANDorOR() is not supported with a size of ");
            Serial.print(size);
            Serial.println(". Aborting write function!");
            return;
        }

        switch (size)
        {
        case 1:
            mode_bits = 1;
            break;
        case 2:
            mode_bits = 2;
            break;
        case 4:
            mode_bits = 3;
            break;
        default:
            break;
        }

        header = header | (mode_bits); //add Mode Bits

        int payload[2 + 2 * size];

        payload[0] = (header & 0xFF00) >> 8;
        payload[1] = header & 0xFF;

        for (int i = 0; i < size; i++) {
            payload[2 + i] = (and_data >> i * 8) & 0xFF;
        }

        for (int i = 0; i < size; i++) {
            payload[2 + size + i] = (or_data >> i * 8) & 0xFF;
        }

        Serial.println("Payload: ");
        for (int i = 0; i < 2 + 2 * size; i++) {
            Serial.println(payload[i], BIN);
        }

        sendBytes(payload, 2 + 2 * size, 0);
}

uint32_t DW3000Class::read(int base, int sub) {    
    uint32_t tmp;
    tmp = readOrWriteFullAddress(base, sub, 0, 0, 0);
    if (DEBUG_OUTPUT) Serial.println("");

    return tmp;
}

uint8_t DW3000Class::read8bit(int base, int sub) {
    return (uint8_t)(read(base, sub) & 0xFF);
}

uint32_t DW3000Class::write(int base, int sub, int data, int data_len) {
    return readOrWriteFullAddress(base, sub, data, data_len, 1);
}

uint32_t DW3000Class::write(int base, int sub, int data) {
    return readOrWriteFullAddress(base, sub, data, 0, 1);
}

uint32_t DW3000Class::readOTP(uint8_t addr) {

    write(OTP_IF_REG, 0x04, addr);

    write(OTP_IF_REG, 0x08, 0x02);

    return read(OTP_IF_REG, 0x10);
}


void DW3000Class::init() {
    Serial.println("\n+++ DecaWave DW3000 Test +++\n");

    if (!checkForDevID()) {
        Serial.println("[ERROR] Dev ID is wrong! Aborting!");
        return;
    }
    
    setBitHigh(GEN_CFG_AES_LOW_REG, 0x10, 4); //MOD2
    
    
    while (!checkForIDLE()) {
        Serial.println("[WARNING] IDLE FAILED (stage 1)");
        delay(100);
    }
    
    softReset(); 

    delay(200);
    
    while (!checkForIDLE()) {
        Serial.println("[WARNING] IDLE FAILED (stage 2)");
        delay(100);
    }
    
    uint32_t ldo_low = readOTP(0x04);
    uint32_t ldo_high = readOTP(0x05);
    uint32_t bias_tune = readOTP(0xA);
    bias_tune = (bias_tune >> 16) & BIAS_CTRL_BIAS_MASK;
    if (ldo_low != 0 && ldo_high != 0 && bias_tune != 0) {
        write(0x11, 0x1F, bias_tune);

        write(0x0B, 0x08, 0x0100);
    }

    int xtrim_value = readOTP(0x1E);
    
    xtrim_value = xtrim_value == 0 ? 0x2E : xtrim_value;

    write(FS_CTRL_REG, 0x14, xtrim_value);
    if (DEBUG_OUTPUT) Serial.print("xtrim: ");
    if (DEBUG_OUTPUT) Serial.println(xtrim_value);
    

    writeSysConfig();
    //0xF2,0x2B,0x0,0x0,0x0,0x2 old values
    DW3000Class::write(0x0, 0x3C, 0xFFFFFFFF); //Set Status Enable
    DW3000Class::write(0x0, 0x40, 0xFF); //Set Status Enable

    DW3000Class::write(0xA, 0x0, 0x900); //AON_DIG_CFG register setup; sets up auto-rx calibration and on-wakeup GO2IDLE  //0xA
    
    /*
     * Set RX and TX config
     */
    DW3000Class::write(0x3, 0x1C, 0x10000240);

    DW3000Class::write(0x3, 0x20, 0x1B6DA489);

    DW3000Class::write(0x3, 0x38, 0x0001C0FD); //DGC_LUT_0
   
    DW3000Class::write(0x3, 0x3C, 0x0001C43E); //DGC_LUT_1
    
    DW3000Class::write(0x3, 0x40, 0x0001C6BE); //DGC_LUT_2
    
    DW3000Class::write(0x3, 0x44, 0x0001C77E); //DGC_LUT_3
    
    DW3000Class::write(0x3, 0x48, 0x0001CF36); //DGC_LUT_4
    
    DW3000Class::write(0x3, 0x4C, 0x0001CFB5); //DGC_LUT_5
    
    DW3000Class::write(0x3, 0x50, 0x0001CFF5); //DGC_LUT_6

    DW3000Class::write(0x3, 0x18, 0xE5E5); //THR_64 value set to 0x32

    int f = DW3000Class::read(0x4, 0x20);

    DW3000Class::write(0x6, 0x0, 0x81101C); 

    write(0x01, 0x04, 0x4001, 2); //change tx antenna delay 
    

    /*
     * Things to do as documented in https://gist.github.com/egnor/455d510e11c22deafdec14b09da5bf54
     */


    DW3000Class::write(0x7, 0x48, 0x14); //LDO_RLOAD to 0x14 //0x7
    DW3000Class::write(0x7, 0x1A, 0xE); //RF_TX_CTRL_1 to 0x0E
    if (config[0] == CHANNEL_5) {
        write(0x7, 0x1C, 0x1C071134); //RF_TX_CTRL_2 to 0x1C071134 (due to channel 5, else (9) to 0x1C010034)
        write(0x9, 0x0, 0x1F3C); //PLL_CFG to 0x1F3C (due to channel 5, else (9) to 0x0F3C)
    }
    else {
        write(0x7, 0x1C, 0x1C010034);
        write(0x9, 0x0, 0x0F3C);
    }

    DW3000Class::write(0x9, 0x8, 0x81); //PLL_CAL config to 0x81
    
    delay(200);
    
    /*for (int i = 0; i < 5; i++) { //MOD2 //siehe dwt_run_pgfcal in makerfabs device_api
        delay(50);
        
        uint32_t h = DW3000Class::read(0x4, 0x20); //Read antenna calibration //RX_CAL_STS => Status bit, if high antenna cal was successful
        if (h > 0) {
            Serial.println("Antenna calibration completed.");
            break;
        }
        else {
            if (i < 4) {
                Serial.println("[WARNING] Antenna auto calibration failed! Retrying...");
                DW3000Class::write(0x4, 0x0C, data22, 1);
            }
            else {
                Serial.println("[ERROR] Antenna auto calibration failed! Aborting!");
            }
        }
    }*/
    
    if (DW3000Class::read(0x4, 0x20)) {
        DW3000Class::write(0x4, 0x20, 0x1);
        Serial.println("[INFO] RX Calibration was successful.");
    }
    f = DW3000Class::read(0x4, 0x20);
    
    DW3000Class::write(0x4, 0x0C, 0x00); //Reset antenna calibration to standard mode
    
    DW3000Class::write(0x11, 0x04, 0xB40200); 

    DW3000Class::write(0x11, 0x08, 0x80030738);
    Serial.println("[INFO] Initialization finished.\n");
}

void DW3000Class::setupGPIO() {
    write(0x05, 0x08, 0xF0); //Set GPIO0 - GPIO3 as OUTPUT on DW3000
}

void DW3000Class::pullLEDHigh(int led) { //led 0 - 2 possible
    if (led > 7) return;
    led_status = led_status + (1 << led);
    write(0x05, 0x0C, led_status);
}

void DW3000Class::pullLEDLow(int led) { //led 0 - 2 possible
    if (led > 7) return;
    led_status = led_status & ~((int)1 << led); //https://stackoverflow.com/questions/47981/how-to-set-clear-and-toggle-a-single-bit
    write(0x05, 0x0C, led_status);
}

void DW3000Class::writeTXDelay(int delay) {
    write(0x00, 0x2C, delay);
}

void DW3000Class::delayedTXThenRX() { //Activates Transmission with delay programmed through writeTXDelay() and goes to receiver immediately
    writeShortCommand(0xF);
}

void DW3000Class::delayedTX() {
    writeShortCommand(0x9);
}

unsigned long long DW3000Class::readRXTimestamp() {
    unsigned long long ts_low = read(0x0C, 0x00);
    unsigned long long ts_high = read(0x0C, 0x04) & 0xFF;
    
    unsigned long long rx_timestamp = (ts_high << 32) | ts_low;
    /*Serial.print("RX: ");
    Serial.println(ts_low);
    Serial.println(ts_high); */

    return rx_timestamp;
}


unsigned long long DW3000Class::readTXTimestamp() {
    unsigned long long ts_low = read(0x00, 0x74);
    unsigned long long ts_high = read(0x00, 0x78) & 0xFF;

    unsigned long long tx_timestamp = (ts_high << 32) + ts_low;
    /*Serial.print("TX: ");
    Serial.println(ts_low);
    Serial.println(ts_high);*/

    return tx_timestamp;
}

    
void DW3000Class::prepareDelayedTX() {
    unsigned long long rx_ts = readRXTimestamp();
    
    int diff = (rx_ts + TRANSMIT_DELAY) & TRANSMIT_DIFF; //Calculate difference between theoretical and practical send time of frame (see DW3000 Manual Sub-Register 0x00:2C for more)
    Serial.print("Diff calc: ");
    Serial.println(diff, BIN);
    int diff_data[] = { (diff & 0xFF), (diff >> 8) & 0x1 };

    int ant_delay = read(GEN_CFG_AES_HIGH_REG, 0x04);
    int ant_data[] = {
    ant_delay & 0xFF,
    (ant_delay >> 8) & 0xFF
    };

    int delay_bits = countBits(TRANSMIT_DELAY);
    int delay_bytes = (delay_bits - TRANSMIT_DELAY % 8) / 8 + 1; //calc the used bytes for transaction
    int delay_data[delay_bytes];
    for (int i = 0; i < delay_bytes; i++) {
        delay_data[i] = (TRANSMIT_DELAY >> i * 8) & 0xFF;
    }

    write(0x00, 0x30, rx_ts & 0xFFFFFFFF, 4); //write shortened 32 bit timestamp to DREF_TIME

    /* FRAME CONTENTS:
    * 0x00 - 0x01: [Reserved] 16 Bit for sender-ID     //TODO add functionality to first 16 bit
    * 0x02 - 0x03: [Used] 9 first Bits used for the calculated difference between theoretical and practical send time (int diff)
    * 0x04 - 0x05: [Used] TX Antenna delay of chip
    * 0x06 - 0x0A: [Used] Variable size of the used delay. Maximum is 5 Bytes
    */
    write(TX_BUFFER_REG, 0x02, diff & 0x1FF);
    write(TX_BUFFER_REG, 0x04, ant_delay & 0xFFFF);
    write(TX_BUFFER_REG, 0x06, TRANSMIT_DELAY);

    setFrameLength(2 + 2 + 2 + delay_bytes); //id + delay_diff + antenna_delay + delay

    //Write delay to register 
    long long del = (long long)TRANSMIT_DELAY >> 8;
    writeTXDelay(del);

    Serial.println("PrepareTX values: ");
    Serial.print("Transmitted diff: ");
    Serial.println(diff);
    Serial.print("Transmitted delay: ");
    Serial.println(TRANSMIT_DELAY, BIN);
    Serial.print("Written delay: ");
    Serial.println(del, BIN);
    Serial.print("Antenna delay: ");
    Serial.println(getTXAntennaDelay(), BIN);
    Serial.print("RX Timestamp:       ");
    Serial.println(rx_ts);
    Serial.print("Calc. TX Timestamp: ");
    Serial.println(rx_ts + (TRANSMIT_DELAY & ~TRANSMIT_DIFF) + getTXAntennaDelay());
}


void DW3000Class::calculateTXRXdiff() { //calc diff on PING side
    unsigned long long tx = readTXTimestamp();
    unsigned long long rx = readRXTimestamp();

    double clk_offset = getClockOffset();
    long double clock_offset = 1.0 - clk_offset / (1 << 26); 

    unsigned int diff = read(RX_BUFFER_0_REG, 0x02) & 0x1FF;
    unsigned int ant_delay = read(RX_BUFFER_0_REG, 0x04) & 0xFFFF;
    unsigned long long delay = read(RX_BUFFER_0_REG, 0x06);
    Serial.print("Delay: ");
    Serial.println(delay);

    if (DEBUG_OUTPUT) {
        Serial.println("\nCalculation Info:");
        Serial.print("RX - TX (raw RTT): ");
        Serial.println(rx - tx - ant_delay);
        Serial.println("RX - TX (computed RTT): ");
        Serial.println(rx - tx - ant_delay + diff);
        Serial.print("Received delay: ");
        Serial.println(delay);
        Serial.print("Received diff: ");
        Serial.println(diff);
    }

    long long travel_time  = ((rx - ant_delay + diff) - tx - (double)(delay * clock_offset)) / 2; //Calculate round-trip-time and divide by 2 (for one distance)
    Serial.println(travel_time);
    //travel_time = travel_time * PS_UNIT;
}

void DW3000Class::calculateRXTXdiff() { //calc diff on PONG side
    unsigned long long tx = readTXTimestamp();
    unsigned long long rx = readRXTimestamp();
    int diff = (rx + TRANSMIT_DELAY - getTXAntennaDelay()) & TRANSMIT_DIFF;

    Serial.println("\n Calculation Info:");
    Serial.print("TX - RX: ");
    Serial.println(tx - rx);
    Serial.print("RX timestamp: ");
    Serial.println(rx);
    Serial.print("TX timestamp: ");
    Serial.println(tx);
    Serial.print("Sent diff: ");
    Serial.println(diff);
    Serial.print("Corrected delay: ");
    Serial.println((tx + diff) - rx - (getTXAntennaDelay() & ~0x1));
    Serial.print("Transmitted delay: ");
    Serial.println(TRANSMIT_DELAY);
    Serial.print("Delay in register: ");
    Serial.println((read(0x00, 0x2C) & ~0x1) << 8, BIN);
    Serial.print("Delay in register + ant delay: ");
    Serial.println(((read(0x00, 0x2C) & ~0x1) << 8) + getTXAntennaDelay());
    getTempInC();
}


/* copied from prepareDelayedTX():
    * FRAME CONTENTS:
    * 0x00 - 0x01: [Reserved] 16 Bit for sender-ID     //TODO add functionality to first 16 bit
    * 0x02 - 0x03: [Used] 9 first Bits used for the calculated difference between theoretical and practical send time (int diff)
    * 0x04 - 0x05: [Used] TX Antenna delay of chip
    * 0x06 - 0x0A: [Used] Variable size of the used delay. Maximum is 5 Bytes
    */
void DW3000Class::printReceivedDataBlocks() {
    int sender_id = read(0x12, 0x00) & 0xFFFF;
    int send_diff = read(0x12, 0x02) & 0x1FF;
    int tx_ant_delay = read(0x12, 0x04) & 0xFFFF;
    int delay1 = read(0x12, 0x06);
    int delay2 = read(0x12, 0x0A);

    Serial.print("Sender ID: ");
    Serial.println(sender_id, BIN);
    Serial.print("Send Diff: ");
    Serial.println(send_diff, BIN);
    Serial.print("TX Antenna Delay: ");
    Serial.println(tx_ant_delay, BIN);
    Serial.print("Delay part 1: ");
    Serial.println(delay1, BIN);
    Serial.print("Delay part 2: ");
    Serial.println(delay2, BIN);
}

void DW3000Class::printRoundTripInformation() {
    long long tx_ts = readTXTimestamp();
    long long rx_ts = readRXTimestamp();

    Serial.print("TX Timestamp: ");
    Serial.println(tx_ts);
    Serial.println(rx_ts);
}

/*void DW3000Class::interruptDetect() { //On calling interrupt
    Serial.println("\n\nCALLED INTERRUPT\n\n");

    int irq_reason = getIRQBit();
    switch (irq_reason) {
    case 0:
        Serial.println("Interruption cause: Interruption Cause not given! Check First and Second Sector Bits.");
        break;
    case 1:
        Serial.println("Interruption cause: TX finished");
        break;
    case 2:
        Serial.println("Interruption cause: RX Data ready");
        DW3000Class::rx_rec = true;
        readRXBuffer();
        break;
    case 3:
        Serial.println("Interruption cause: Preamble detected");
        //initiateRX();
        digitalWrite(TX_LED, HIGH);
        digitalWrite(RX_LED, HIGH);
        delay(50);
        digitalWrite(TX_LED, LOW);
        digitalWrite(RX_LED, LOW);
        break;
    case 4:
        Serial.println("Interruption cause: Cmd Error");
        cmd_error = true;
        SPI.endTransaction();
        break;
    default:
        Serial.print("irq_reason got wrong value. Value: ");
        Serial.println(irq_reason);
        break;
    }
    //IRQPulled = true;
    resetIRQStatusBits();
    //initiateRX();
    Serial.println("Finished interrupt. Continuing...");
}*/


void DW3000Class::writeShortCommand(int cmd) {
    if (DEBUG_OUTPUT) Serial.print("[INFO] Executing short command: ");

    int header = 0;

    header = header | 0x1;
    header = header | (cmd & 0x1F) << 1;
    header = header | 0x80;

    if (DEBUG_OUTPUT) Serial.println(header, BIN);

    int header_arr[] = { header };

    sendBytes(header_arr, 1, 0);
}

int DW3000Class::receivedFrameSucc() { //No frame received: 0; frame received: 1; error while receiving: 2
    int sys_stat = read(GEN_CFG_AES_LOW_REG, 0x44);
    if ((sys_stat & SYS_STATUS_FRAME_RX_SUCC) > 0) {
        return 1;
    }
    else if ((sys_stat & SYS_STATUS_RX_ERR) > 0) {
        return 2;
    }
    return 0;
}

int DW3000Class::sentFrameSucc() { //No frame sent: 0; frame sent: 1; error while sending: 2
    int sys_stat = read(GEN_CFG_AES_LOW_REG, 0x44);
    if ((sys_stat & SYS_STATUS_FRAME_TX_SUCC) == SYS_STATUS_FRAME_TX_SUCC) {
        return 1;
    }
    Serial.println(sys_stat, BIN);
    return 0;
}

unsigned long long DW3000Class::readRXBuffer() { // deprecated! Use read(RX_BUFFER_0_REG, [...]); instead
    //Serial.print("Reading RX Buffer0... ");
    unsigned long long buf0 = read(RX_BUFFER_0_REG, 0x0);
    buf0 = buf0 + (read(0x12, 0x20) << 32);
    
    return buf0;
}

void DW3000Class::standardTX() {
    DW3000Class::writeShortCommand(0x01);
}

void DW3000Class::standardRX() {
    DW3000Class::writeShortCommand(0x02);
}

void DW3000Class::TXInstantRX() { // Execute tx, then set receiver to rx instantly
    DW3000Class::writeShortCommand(0x0C);
}

void DW3000Class::clearSystemStatus() {
    write(GEN_CFG_AES_LOW_REG, 0x44, 0x3F7FFFFF);
    write(GEN_CFG_AES_LOW_REG, 0x48, 0x1FF2);
}

int DW3000Class::checkForDevID() {
    if (read(GEN_CFG_AES_LOW_REG, NO_OFFSET) != 0xDECA0302) {
        Serial.println("[ERROR] DEV_ID IS WRONG!");
        return 0;
    }
    return 1;
}

void DW3000Class::setFrameLength(int frame_len) { // set Frame length in Bytes
    frame_len = frame_len + FCS_LEN;
    int curr_cfg = read(0x00, 0x24);
    if (frame_len > 1023) {
        Serial.println("[ERROR] Frame length + FCS_LEN (2) is longer than 1023. Aborting!");
        return;
    }
    int tmp_cfg = (curr_cfg & 0xFFFFFC00) | frame_len;
   
    int old = read(GEN_CFG_AES_LOW_REG, 0x24);
    write(GEN_CFG_AES_LOW_REG, 0x24, tmp_cfg);
    int h = read(GEN_CFG_AES_LOW_REG, 0x24);
}

/*
* Set bit in a defined register address
*/
void DW3000Class::setBit(int reg_addr, int sub_addr, int shift, bool b) {
    uint8_t tmpByte = read8bit(reg_addr, sub_addr);
    if (b) {
        bitSet(tmpByte, shift);
    }
    else {
        bitClear(tmpByte, shift);
    }
    write(reg_addr, sub_addr, tmpByte);
}

void DW3000Class::setBitHigh(int reg_addr, int sub_addr, int shift) {
    setBit(reg_addr, sub_addr, shift, 1);
}
void DW3000Class::setBitLow(int reg_addr, int sub_addr, int shift) {
    setBit(reg_addr, sub_addr, shift, 0);
}


/*
    ==== CONFIGURATION FUNCTIONS ====
*/

void DW3000Class::setChannel(uint8_t data) {
    if(data == CHANNEL_5 || data == CHANNEL_9) config[0] = data;
}

void DW3000Class::setPreambleLength(uint8_t data) {
    if (data == PREAMBLE_32 || data == PREAMBLE_64 || data == PREAMBLE_1024 ||
        data == PREAMBLE_256 || data == PREAMBLE_512 || data == PREAMBLE_1024 ||
        data == PREAMBLE_1536 || data == PREAMBLE_2048 || data == PREAMBLE_4096) config[1] = data;
}

void DW3000Class::setPreambleCode(uint8_t data) {
    if (data <= 12 && data >= 9) config[2] = data;
}

void DW3000Class::setPACSize(uint8_t data) {
    if (data == PAC4 || data == PAC8 || data == PAC16 || data == PAC32) config[3] = data;
}

void DW3000Class::setDatarate(uint8_t data) {
    if (data == DATARATE_6_8MB || data == DATARATE_850KB) config[4] = data;
}

void DW3000Class::setPHRMode(uint8_t data) {
    if (data == PHR_MODE_STANDARD || data == PHR_MODE_LONG) config[5] = data;
}

void DW3000Class::setPHRRate(uint8_t data) {
    if (data == PHR_RATE_6_8MB || data == PHR_RATE_850KB) config[6] = data;
}

void DW3000Class::setTXAntennaDelay(int delay) {
    write(0x01, 0x04, delay);
}

int DW3000Class::getTXAntennaDelay() {
    return(read(0x01, 0x04));
}

float DW3000Class::getClockOffset() {      
    if (config[0] == CHANNEL_5) {
        return getRawClockOffset() * CLOCK_OFFSET_CHAN_5_CONSTANT / 1000000;
    }
    else {
        return getRawClockOffset() * CLOCK_OFFSET_CHAN_9_CONSTANT / 1000000;
    }
}

int DW3000Class::getRawClockOffset() {
    int raw_offset = read(0x06, 0x29) & 0x1FFFFF;
    
    if (DEBUG_OUTPUT) {
        Serial.print("Raw offset: ");
        Serial.println(raw_offset);
    }
    return raw_offset;
}


float DW3000Class::getTempInC() {
    write(0x07, 0x34, 0x4); //enable temp sensor readings

    write(0x08, 0x00, 0x1); //enable poll

    while (!(read(0x08, 0x04) & 0x01)) {
    };
    int res = read(0x08, 0x08);
    res = (res & 0xFF00 ) >> 8;
    int otp_temp = readOTP(0x09) & 0xFF;
    float tmp = (float)((res - otp_temp) * 1.05f) + 22.0f;

    write(0x08, 0x00, 0x0); //Reset poll enable

    return tmp;
}


unsigned int DW3000Class::countBits(unsigned int number) {
    return (int)log2(number) + 1;
}


void DW3000Class::printDouble(double val, unsigned int precision) { //https://forum.arduino.cc/t/printing-a-double-variable/44327/2
    // prints val with number of decimal places determine by precision
    // NOTE: precision is 1 followed by the number of zeros for the desired number of decimial places
    // example: printDouble( 3.1415, 100); // prints 3.14 (two decimal places)

    Serial.print(int(val));  //prints the int part
    Serial.print("."); // print the decimal point
    unsigned int frac;
    if (val >= 0)
        frac = (val - int(val)) * precision;
    else
        frac = (int(val) - val) * precision;
    Serial.println(frac, DEC);
}